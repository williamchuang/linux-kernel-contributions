/* Bounded exhaustive verification by enumeration, on the real ported
 * assoc_array code (fan-out 4).  Family: 5 "cluster" keys sharing seg0=0,seg1=0,
 * distinguished by seg2 in {0..3}; plus 1 key diverging at seg1.  Enumerates
 * all 4^5 segment assignments and, separately, all 6! insertion orders of the
 * canonical assignment, running the genuine insert+find on each. */
#include "aa_shim.h"
#include <stdio.h>
#define KW 1
#define N 6
struct key1 { unsigned long w[KW]; };
struct obj { struct key1 key; };
static unsigned long gkc(const void*ik,int lv){int i=lv/BITS_PER_LONG;return i<KW?((const struct key1*)ik)->w[i]:0;}
static unsigned long gokc(const void*o,int lv){int i=lv/BITS_PER_LONG;return i<KW?((const struct obj*)o)->key.w[i]:0;}
static bool cmp(const void*o,const void*ik){return !memcmp(&((const struct obj*)o)->key,ik,sizeof(struct key1));}
static int diff(const void*o,const void*ik){unsigned long x=((const struct obj*)o)->key.w[0]^((const struct key1*)ik)->w[0];return x?__builtin_ctzl(x):-1;}
static void fobj(void*o){free(o);}
static const struct assoc_array_ops ops={gkc,gokc,cmp,diff,fobj};
static void setseg(struct key1*k,int bit,unsigned long v){k->w[0]&=~(3UL<<bit);k->w[0]|=(v&3)<<bit;}

/* Run the family with given seg2 values and insertion order; return #findable. */
static int run(const unsigned char *seg2, const int *order)
{
	struct assoc_array arr; assoc_array_init(&arr);
	struct obj *objs[N]; struct key1 K[N]; int i, f = 0;
	for (i = 0; i < N; i++) {
		K[i].w[0] = (unsigned long)(i + 1) << 16;   /* unique high bits */
		setseg(&K[i], 0, 0);
		if (i < N - 1) { setseg(&K[i], 2, 0); setseg(&K[i], 4, seg2[i]); }
		else setseg(&K[i], 2, 1);
	}
	for (i = 0; i < N; i++) {
		int j = order ? order[i] : i;
		objs[j] = malloc(sizeof(struct obj)); objs[j]->key = K[j];
		struct assoc_array_edit *e = assoc_array_insert(&arr, &ops, &objs[j]->key, objs[j]);
		assoc_array_apply_edit(e);
	}
	for (i = 0; i < N; i++) if (assoc_array_find(&arr, &ops, &K[i]) == objs[i]) f++;
	assoc_array_destroy(&arr, &ops);
	return f;
}
static long total, failed;
static void check(const unsigned char*seg2,const int*order){ total++; if(run(seg2,order)!=N) failed++; }
/* enumerate all 6! orders */
static void perm(int *a,int k,const unsigned char*seg2){
	if(k==N){ check(seg2,a); return; }
	for(int i=k;i<N;i++){ int t=a[k];a[k]=a[i];a[i]=t; perm(a,k+1,seg2); t=a[k];a[k]=a[i];a[i]=t; }
}
int main(void){
	unsigned char seg2[N-1]; long combos=0, combo_fail=0;
	/* Sweep 1: all 4^5 seg2 assignments, canonical insertion order. */
	for(long m=0;m<1024;m++){ for(int i=0;i<N-1;i++) seg2[i]=(m>>(2*i))&3;
		combos++; if(run(seg2,NULL)!=N) combo_fail++; }
	printf("Sweep 1 (all %ld segment assignments, canonical order): %ld fail find-all\n", combos, combo_fail);
	/* Sweep 2: canonical seg2 = {0,1,2,3,0}, all 720 insertion orders. */
	unsigned char cs[5]={0,1,2,3,0}; int a[N]; for(int i=0;i<N;i++)a[i]=i;
	total=failed=0; perm(a,0,cs);
	printf("Sweep 2 (all %ld insertion orders, canonical segments): %ld fail find-all\n", total, failed);
	printf("VERDICT: mainline code fails to find all keys in %ld/%ld + %ld/%ld enumerated cases\n",
	       combo_fail, combos, failed, total);
	return 0;
}
