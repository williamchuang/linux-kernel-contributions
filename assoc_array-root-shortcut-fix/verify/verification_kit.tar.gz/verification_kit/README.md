# assoc_array verification kit

Runs the exhaustive-enumeration and reproducer checks against a Linux source
tree. The code under test is taken from that tree; no kernel source is included
here.

    ./run_verification.sh /path/to/linux

The script extracts the real `lib/assoc_array.c` and `assoc_array_priv.h`, builds
a userspace port behind `aa_shim.h` (kernel-macro stubs only; the assoc_array
functions are unmodified), derives the buggy and fixed variants, and runs:

- the fan-out-4 exhaustive enumeration (1024 segment assignments + 720 insertion
  orders),
- the 18-key reproducer at fan-out 16,
- a 200,000-run randomized stress on the fixed variant.

Expected: the buggy variant fails 1024/1024 + 120/720 and the reproducer shows
findable = 2; the fixed variant passes everything and the reproducer shows
findable = 18.

## Files

- `run_verification.sh` — driver.
- `aa_shim.h` — kernel-macro stubs for the userspace port.
- `enum_verify.c` — fan-out-4 exhaustive enumeration.
- `harness_repro.c` — 18-key reproducer at fan-out 16.
- `stress_fixed.c` — randomized differential stress.
