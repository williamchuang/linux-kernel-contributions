#include "aa_shim.h"
#include <stdio.h>
#define KW 3
struct key3 { unsigned long w[KW]; };
struct obj { struct key3 key; unsigned int idx; };
static unsigned long chunk(const struct key3 *k, int lv){ int i=lv/BITS_PER_LONG; return i<KW?k->w[i]:0; }
static unsigned long gkc(const void*ik,int lv){ return chunk(ik,lv);}
static unsigned long gokc(const void*o,int lv){ return chunk(&((const struct obj*)o)->key,lv);}
static bool cmp(const void*o,const void*ik){ return !memcmp(&((const struct obj*)o)->key,ik,sizeof(struct key3)); }
static int diff(const void*o,const void*ik){ const struct key3*a=&((const struct obj*)o)->key,*b=ik; for(int i=0;i<KW;i++){unsigned long x=a->w[i]^b->w[i]; if(x) return i*BITS_PER_LONG+__builtin_ctzl(x);} return -1; }
static void fobj(void*o){ free(o);}
static const struct assoc_array_ops ops={gkc,gokc,cmp,diff,fobj};
static void setn(struct key3*k,int bit,unsigned long v){int w=bit/BITS_PER_LONG,s=bit%BITS_PER_LONG;k->w[w]&=~(0xfUL<<s);k->w[w]|=(v&0xf)<<s;}
static int cnt(const void*o,void*d){(*(unsigned*)d)++;return 0;}
int main(void){
  struct assoc_array arr; assoc_array_init(&arr);
  struct obj *objs[18]; struct key3 keys[18];
  for(unsigned i=0;i<18;i++){ memset(&keys[i],0,sizeof(keys[i])); setn(&keys[i],4,i<17?0:1); setn(&keys[i],8,i&0xf); setn(&keys[i],12,(i>>4)&0xf); keys[i].w[KW-1]=0x100+i; }
  for(unsigned i=0;i<18;i++){ objs[i]=calloc(1,sizeof(struct obj)); objs[i]->key=keys[i]; objs[i]->idx=i;
    struct assoc_array_edit*e=assoc_array_insert(&arr,&ops,&objs[i]->key,objs[i]); if(IS_ERR(e)){printf("ENOMEM\n");return 2;} assoc_array_apply_edit(e); }
  unsigned iter=0; assoc_array_iterate(&arr,cnt,&iter);
  unsigned findable=0; for(unsigned i=0;i<18;i++) if(assoc_array_find(&arr,&ops,&keys[i])==objs[i]) findable++;
  printf("iterate=%u nr_leaves=%lu findable=%u (all should be 18)\n", iter, arr.nr_leaves_on_tree, findable);
  return findable==18?0:1;
}
