#!/bin/sh
# Reproduce the assoc_array verification against a Linux source tree.
# Usage: ./run_verification.sh /path/to/linux
set -e
TREE="$1"
[ -z "$TREE" ] && { echo "usage: $0 /path/to/linux-source-tree"; exit 1; }
KIT="$(cd "$(dirname "$0")" && pwd)"
WORK="$(mktemp -d)"; trap 'rm -rf "$WORK"' EXIT
cp "$KIT"/aa_shim.h "$KIT"/enum_verify.c "$KIT"/harness_repro.c "$KIT"/stress_fixed.c "$WORK"/
# Extract the real priv.h body (structs + tag helpers) and the .c body.
awk 'NR>=16' "$TREE/include/linux/assoc_array_priv.h" | grep -v '#include' | grep -v '#ifdef CONFIG_ASSOCIATIVE_ARRAY' > "$WORK/aa_priv_body.h"
# drop the trailing two #endif of the header guards
sed -i '${/#endif/d}' "$WORK/aa_priv_body.h"; sed -i '${/#endif/d}' "$WORK/aa_priv_body.h"
# allow fan-out override
sed -i 's/^#define ASSOC_ARRAY_FAN_OUT[[:space:]].*$/#ifndef ASSOC_ARRAY_FAN_OUT\n#define ASSOC_ARRAY_FAN_OUT 16\n#endif/' "$WORK/aa_priv_body.h"
grep -v '^#include' "$TREE/lib/assoc_array.c" > "$WORK/aa_body_under_test.c"
# Derive buggy and fixed variants from whichever is present.
python3 - "$WORK" <<'PY'
import sys
w=sys.argv[1]; s=open(w+"/aa_body_under_test.c").read()
buggy="\tlevel += ASSOC_ARRAY_LEVEL_STEP;\n\tif (diff > level) {"
fixed="\tlevel += ASSOC_ARRAY_LEVEL_STEP;\n\tif (diff > level ||\n\t    (!shortcut->back_pointer && diff > level - ASSOC_ARRAY_LEVEL_STEP)) {"
if buggy in s: b=s; f=s.replace(buggy,fixed)
elif fixed in s: f=s; b=s.replace(fixed,buggy)
else: sys.exit("could not locate the split condition in assoc_array.c")
open(w+"/aa_body_buggy.c","w").write(b); open(w+"/aa_body_fixed.c","w").write(f)
PY
for V in buggy fixed; do
  printf '#include "aa_shim.h"\n#include "aa_priv_body.h"\n#include "aa_body_%s.c"\n' "$V" > "$WORK/aa_standalone_$V.c"
done
cd "$WORK"
echo "=== Exhaustive enumeration (fan-out 4) ==="
for V in buggy fixed; do
  gcc -O2 -w -DASSOC_ARRAY_FAN_OUT=4 enum_verify.c aa_standalone_$V.c -o enum_$V
  printf "[%s] " "$V"; ./enum_$V | tail -1
done
echo "=== 18-key reproducer (fan-out 16) ==="
for V in buggy fixed; do
  gcc -O2 -w harness_repro.c aa_standalone_$V.c -o repro_$V
  printf "[%s] " "$V"; ./repro_$V
done
echo "=== Randomized differential stress (fan-out 16, fixed) ==="
gcc -O2 -w stress_fixed.c aa_standalone_fixed.c -o sf && ./sf
