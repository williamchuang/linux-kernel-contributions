/* Userspace/CBMC shim for lib/assoc_array.c — kernel macro stubs only.
 * The assoc_array functions themselves are the real, unmodified kernel code. */
#ifndef AA_SHIM_H
#define AA_SHIM_H
#include <stdlib.h>
#include <string.h>
#include <stdint.h>
#include <stdbool.h>
#include <limits.h>
#include <assert.h>
#include <stddef.h>

typedef uint8_t u8;
#define ENOMEM 12
#define ERR_PTR(e)  ((void *)(long)(e))
#define PTR_ERR(p)  ((long)(p))
#define IS_ERR(p)   ((unsigned long)(void *)(p) >= (unsigned long)-4095)
#ifndef BITS_PER_LONG
#define BITS_PER_LONG (int)(8 * sizeof(unsigned long))
#endif

#define ilog2(n)        ((unsigned)(8 * sizeof(unsigned long long) - __builtin_clzll((unsigned long long)(n)) - 1))
#define round_up(x, y)  ((((x) - 1) | ((typeof(x))(y) - 1)) + 1)
#define round_down(x, y) ((x) & ~((typeof(x))(y) - 1))
#define __ffs(x)        ((unsigned long)__builtin_ctzl(x))

#define pr_devel(...)   do {} while (0)
#define EXPORT_SYMBOL(x)
#define fallthrough     __attribute__((__fallthrough__))
#ifndef likely
#define likely(x)   (x)
#define unlikely(x) (x)
#endif

/* BUG_ON / BUG become checkable assertions. */
#define BUG_ON(cond)    assert(!(cond))
#define BUG()           assert(0)

#define READ_ONCE(x)    (x)
#define WRITE_ONCE(x, v) ((x) = (v))
#define smp_wmb()       do {} while (0)

#define container_of(ptr, type, member) \
	((type *)((char *)(ptr) - offsetof(type, member)))

struct rcu_head { void *func_placeholder; };
#ifdef CBMC_NO_RCU
/* Insert-only proof: skip deferred cleanup (harmless leak; avoids recursive free). */
#define call_rcu(head, fn)  do {} while (0)
#else
#define call_rcu(head, fn)  (fn)(head)
#endif

/* Allocation helpers used by assoc_array.c. */
#define kzalloc_obj(T, ...)            ((T *)calloc(1, sizeof(T)))
#define kzalloc_flex(P, FAM, CNT, ...) ((typeof(P) *)calloc(1, sizeof(typeof(P)) + (CNT) * sizeof(((typeof(P) *)0)->FAM[0])))
#define kmalloc_flex(P, FAM, CNT, ...) kzalloc_flex(P, FAM, CNT)
#define struct_size(P, FAM, CNT)       (sizeof(*(P)) + (CNT) * sizeof((P)->FAM[0]))
#define flex_array_size(P, FAM, CNT)   ((CNT) * sizeof((P)->FAM[0]))
#define kfree(p)                       free(p)
#define ARRAY_SIZE(a)                   (sizeof(a) / sizeof((a)[0]))

/* ---- from include/linux/assoc_array.h ---- */
struct assoc_array {
	struct assoc_array_ptr *root;
	unsigned long nr_leaves_on_tree;
};
struct assoc_array_ops {
	unsigned long (*get_key_chunk)(const void *index_key, int level);
	unsigned long (*get_object_key_chunk)(const void *object, int level);
	bool (*compare_object)(const void *object, const void *index_key);
	int (*diff_objects)(const void *object, const void *index_key);
	void (*free_object)(void *object);
};
#define ASSOC_ARRAY_KEY_CHUNK_SIZE BITS_PER_LONG
static inline void assoc_array_init(struct assoc_array *array)
{
	array->root = NULL;
	array->nr_leaves_on_tree = 0;
}
struct assoc_array_edit;
extern int assoc_array_iterate(const struct assoc_array *array,
	int (*iterator)(const void *object, void *iterator_data), void *iterator_data);
extern void *assoc_array_find(const struct assoc_array *array,
	const struct assoc_array_ops *ops, const void *index_key);
extern struct assoc_array_edit *assoc_array_insert(struct assoc_array *array,
	const struct assoc_array_ops *ops, const void *index_key, void *object);
extern void assoc_array_insert_set_object(struct assoc_array_edit *edit, void *object);
extern void assoc_array_apply_edit(struct assoc_array_edit *edit);
extern void assoc_array_cancel_edit(struct assoc_array_edit *edit);
#endif
