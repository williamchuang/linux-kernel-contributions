/* Broad randomized differential stress on the fixed port (fan-out 16):
 * random clustered + random keys, random insert order, assert all findable. */
#include "aa_shim.h"
#include <stdio.h>
#define KW 3
struct key3{unsigned long w[KW];};
struct obj{struct key3 key;};
static unsigned long gkc(const void*ik,int lv){int i=lv/BITS_PER_LONG;return i<KW?((const struct key3*)ik)->w[i]:0;}
static unsigned long gokc(const void*o,int lv){int i=lv/BITS_PER_LONG;return i<KW?((const struct obj*)o)->key.w[i]:0;}
static bool cmp(const void*o,const void*ik){return !memcmp(&((const struct obj*)o)->key,ik,sizeof(struct key3));}
static int diff(const void*o,const void*ik){const struct key3*a=&((const struct obj*)o)->key,*b=ik;for(int i=0;i<KW;i++){unsigned long x=a->w[i]^b->w[i];if(x)return i*BITS_PER_LONG+__builtin_ctzl(x);}return -1;}
static void fobj(void*o){free(o);}
static const struct assoc_array_ops ops={gkc,gokc,cmp,diff,fobj};
static unsigned long rs=88172645463325252UL;
static unsigned long xr(void){rs^=rs<<13;rs^=rs>>7;rs^=rs<<17;return rs;}
int main(void){
  long runs=200000, fails=0; int M=20;
  for(long r=0;r<runs;r++){
    int n=2+xr()%M; struct assoc_array arr; assoc_array_init(&arr);
    struct obj**objs=calloc(n,sizeof*objs); struct key3*K=calloc(n,sizeof*K);
    int mode=xr()%3;
    for(int i=0;i<n;i++){
      for(int w=0;w<KW;w++)K[i].w[w]=0;
      if(mode==0){ /* heavy clustering: only low 16 bits vary */ K[i].w[0]=xr()&0xffff; }
      else if(mode==1){ /* share long prefix, vary one nibble + unique tail */ K[i].w[0]=(xr()&0xf)<<4; K[i].w[KW-1]=0x1000+i; }
      else { for(int w=0;w<KW;w++)K[i].w[w]=xr(); }
      /* ensure distinct */ int dup; do{dup=0;for(int j=0;j<i;j++)if(!memcmp(&K[i],&K[j],sizeof(struct key3))){dup=1;K[i].w[KW-1]+=0x777+i;break;}}while(dup);
    }
    /* random insertion order */ int*ord=calloc(n,sizeof(int)); for(int i=0;i<n;i++)ord[i]=i;
    for(int i=n-1;i>0;i--){int j=xr()%(i+1);int t=ord[i];ord[i]=ord[j];ord[j]=t;}
    for(int i=0;i<n;i++){int j=ord[i];objs[j]=malloc(sizeof(struct obj));objs[j]->key=K[j];struct assoc_array_edit*e=assoc_array_insert(&arr,&ops,&objs[j]->key,objs[j]);assoc_array_apply_edit(e);}
    int f=0; for(int i=0;i<n;i++) if(assoc_array_find(&arr,&ops,&K[i])==objs[i]) f++;
    if(f!=n) fails++;
    assoc_array_destroy(&arr,&ops); free(objs);free(K);free(ord);
  }
  printf("fixed port stress: %ld runs, %ld with a missing key\n", runs, fails);
  return fails?1:0;
}
